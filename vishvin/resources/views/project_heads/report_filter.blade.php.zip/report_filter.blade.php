
@include("inc_admin.header")


@php
use App\Models\Admin;
use App\Models\Zone_code;
@endphp

<div class="main-content">

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">

                    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                        <h4 class="mb-sm-0">Reports</h4>
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item">
                                    <a href="javascript: void(0);">Admin</a></li>
                                <li class="breadcrumb-item active">Release Meter Report</li>
                            </ol>
                        </div>

                    </div>


                </div>


            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-xl-12 col-md-12 dash-xl-100 dash-lg-100 dash-39">
                    <div class="card ongoing-project recent-orders">
                        <div class="card-header border-0 align-items-center d-flex">
                            <h4 class="card-title mb-0 flex-grow-1">Report Filter</h4>
                        </div>
                        {{-- filter --}}
                        <div class="container-fluid">
                                <form method="POST" action="{{url('/')}}/project_heads/report_filter">
                                    @csrf
                                    <div class="row">

                                @if (session('rexkod_vishvin_auth_user_type') == 'ae')
                                @php
                                    $admin = Admin::where('id',session('rexkod_vishvin_auth_userid'))->first();
                                    $zone_code = Zone_code::where('so_code',$admin->so_pincode)->first();
                                @endphp
                                <div class="col-4" style="display: none;">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                                <input type="text" name="division" value="{{$zone_code->div_code}}">
                                        {{-- <select class="form-control" name="division" id="" >
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>
                                            <option value="530010">Belagavi, 530010</option>
                                                <option value="530016">Vijayapura, 530016</option>
                                        </select> --}}
                                    </div>
                                </div>
                                <div class="col-4" style="display: none;">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Sub Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                                <input type="text" name="sub_division" value="{{$zone_code->sd_code}}">
                                        {{-- <select class="form-control" name="sub_division" id="" >
                                            <option value="" selected="selected">
                                            </option>

                                        </select> --}}
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Section <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="section" id="">
                                            <option value="{{$admin->so_pincode}}" selected="selected">{{$admin->so_pincode}}
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                @elseif(session('rexkod_vishvin_auth_user_type') == 'aee' || session('rexkod_vishvin_auth_user_type') == 'aao')
                                @php
                                    $admin = Admin::where('id',session('rexkod_vishvin_auth_userid'))->first();
                                    $zone_code = Zone_code::where('sd_code',$admin->sd_pincode)->first();
                                @endphp
                                <div class="col-4" style="display: none;">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                                <input type="text" name="division" value="{{$zone_code->div_code}}">
                                        {{-- <select class="form-control" name="division" id="">
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>
                                            <option value="530010">Belagavi, 530010</option>
                                                <option value="530016">Vijayapura, 530016</option>
                                        </select> --}}
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Sub Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="sub_division" id="sub_division2">
                                            <option value="{{$admin->sd_pincode}}" selected="selected">{{$admin->sd_pincode}}
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Section <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="section" id="section2">
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                @elseif(session('rexkod_vishvin_auth_user_type') == 'project_head' || session('rexkod_vishvin_auth_user_type') == 'hescom_manager')
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="division" id="division">
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>
                                            <option value="530001">Hubballi, 530001</option>
                                            <option value="530003">Dharwad, 530003</option>
                                            <option value="530005">Gadag, 530005</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Sub Division <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="sub_division" id="sub_division">
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Select Section <span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="section" id="section">
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>

                                        </select>
                                    </div>
                                </div>
                                @endif


                                <div class="col-4">
                                    <div class="mb-3">
                                        <label class="form-label" for="product-title-input">Report Type<span
                                                class="mandatory_star">*<sup><i>required</i></sup></span></label>
                                        <select class="form-control" name="report_type" id="" required>
                                            <option value="" disabled="disabled" selected="selected">Please Select
                                            </option>
                                            <option value="1">Release Meter Report</option>
                                            <option value="2">Meter Replacement Report</option>
                                            <option value="3">ANX-1 Abstract Report</option>
                                            <option value="4">ANX-1 Detailed Report</option>
                                            <option value="5">ANX-3 Report</option>


                                        </select>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="row mb-2">
                                        <div class="col-lg-3 d-flex">
                                            <input type="radio" name="format" id="daily" value="daily">
                                            <label for="daily" style="margin-bottom:0;">Daily</label>
                                        </div>
                                        <div class="col-lg-3 d-flex">
                                            <input type="radio" name="format" id="weekly" value="weekly">
                                            <label for="weekly" style="margin-bottom:0;">Weekly</label>
                                        </div>
                                        <div class="col-lg-3 d-flex">
                                            <input type="radio" name="format" id="monthly" value="monthly">
                                            <label for="monthly" style="margin-bottom:0;">Monthly</label>
                                        </div>
                                        <div class="col-lg-3 d-flex">
                                            <input type="radio" name="format" id="custom" value="custom">
                                            <label for="custom" style="margin-bottom:0;">Custom</label>
                                        </div>
                                    </div>
                                    <div class="row mb-2" id="custom_date" style="display: none">
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                            <label for="start_date">Start Date:</label>
                                            <input type="date" class="form-control" name="start_date" id="start_date">
                                            </div>
                                        </div>
                                        <div class="col-lg-4">
                                            <div class="form-group">
                                            <label for="end_date">End Date:</label>
                                            <input type="date" class="form-control" name="end_date" id="end_date">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <div class="row mb-2">
                                        <div class="col-lg-4">
                                            {{-- <label for="end_date">Action </label> --}}
                                            <button type="submit" name= "inward" class="btn btn-primary">Search</button>
                                        </div>
                                    </div>
                                </div>
                                </form>

                        </div>
                        {{-- filter end --}}


                    </div>
                </div>

            </div>


        </div>
        <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


</div>




@include('inc_admin.footer')


<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"
    integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.9.2/themes/base/jquery-ui.css">
<script type="text/javascript" src="//cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/responsive/1.12.1/css/dataTables.responsive.css">
<script type="text/javascript" src="//cdn.datatables.net/responsive/1.12.1/js/dataTables.responsive.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/buttons/2.2.3/css/buttons.dataTables.min.css">


<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>

<script>
    $(document).ready(function() {
        $('.table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'excelHtml5'
            ]
        });
    });
</script>
<script>

    $(document).ready(function() {
    $('#division').change(function() {
        var division = $(this).val();
        $('#sub_division').empty();
        $('#sub_division').append($('<option>', { value: '', text: '-- Select --' }));
        if(division) {
            $.get('/project_heads/get_sd_code/' + division, function(sd_codes) {
                $.each(sd_codes, function(i, code) {
                    // console.log(code);
                    var option_text = code.sd_code + ' , ' + code.sub_division;
                    $('#sub_division').append($('<option>', { value: code.sd_code, text: option_text }));
                });
            });
        }
    }).trigger('change'); // Trigger the change event on page load
});

$(document).ready(function() {
    $('#sub_division').change(function() {
        var division = $(this).val();
        $('#section').empty();
        $('#section').append($('<option>', { value: '', text: '-- Select --' }));
        if(division) {
            $.get('/project_heads/get_so_code/' + division, function(so_codes) {
                $.each(so_codes, function(i, code) {
                    // console.log(code);
                    var option_text = code.so_code + ' , ' + code.section_office;
                    $('#section').append($('<option>', { value: code.so_code, text: option_text }));
                });
            });
        }
    }).trigger('change'); // Trigger the change event on page load
});

</script>
{{-- aee --}}
<script>

$(document).ready(function() {
    function fetchAndPopulateSections(division) {
        $('#section2').empty();
        $('#section2').append($('<option>', { value: '', text: '-- Select --' }));
        if (division) {
            $.get('/project_heads/get_so_code/' + division, function(so_codes) {
                $.each(so_codes, function(i, code) {
                    var option_text = code.so_code + ' , ' + code.section_office;
                    $('#section2').append($('<option>', { value: code.so_code, text: option_text }));
                });
            });
        }
    }

    // Trigger the function on page load
    fetchAndPopulateSections($('#sub_division2').val());

    // Attach the change event handler
    $('#sub_division2').change(function() {
        var division = $(this).val();
        fetchAndPopulateSections(division);
    });
});

</script>

<script>

    document.addEventListener('DOMContentLoaded', function() {
    var dailyRadio = document.querySelector('#daily');
    var weeklyRadio = document.querySelector('#weekly');
    var monthlyRadio = document.querySelector('#monthly');
    var customRadio = document.querySelector('#custom');
    var customDiv = document.querySelector('#custom_date');

    dailyRadio.addEventListener('change', function() {
        customDiv.style.display = 'none';
    });

    weeklyRadio.addEventListener('change', function() {
        customDiv.style.display = 'none';
    });

    monthlyRadio.addEventListener('change', function() {
        customDiv.style.display = 'none';
    });

    customRadio.addEventListener('change', function() {
        customDiv.style.display = '';
    });
});


</script>
